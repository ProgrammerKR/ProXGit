﻿USE [master]
GO
/****** Object:  Database [gitea]    Script Date: 05/05/2019 11:33:04 ******/
CREATE DATABASE [gitea]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'gitea', FILENAME = N'/var/opt/mssql/data/gitea.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'gitea_log', FILENAME = N'/var/opt/mssql/data/gitea_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [gitea].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [gitea] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [gitea] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [gitea] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [gitea] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [gitea] SET ARITHABORT OFF 
GO
ALTER DATABASE [gitea] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [gitea] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [gitea] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [gitea] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [gitea] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [gitea] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [gitea] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [gitea] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [gitea] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [gitea] SET  ENABLE_BROKER 
GO
ALTER DATABASE [gitea] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [gitea] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [gitea] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [gitea] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [gitea] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [gitea] SET RECOVERY FULL 
GO
ALTER DATABASE [gitea] SET  MULTI_USER 
GO
ALTER DATABASE [gitea] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [gitea] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [gitea] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [gitea] SET DELAYED_DURABILITY = DISABLED 
GO
EXEC sys.sp_db_vardecimal_storage_format N'gitea', N'ON'
GO
ALTER DATABASE [gitea] SET QUERY_STORE = OFF
GO
USE [gitea]
GO
ALTER DATABASE SCOPED CONFIGURATION SET IDENTITY_CACHE = ON;
GO
ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET LEGACY_CARDINALITY_ESTIMATION = PRIMARY;
GO
ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 0;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET MAXDOP = PRIMARY;
GO
ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = ON;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET PARAMETER_SNIFFING = PRIMARY;
GO
ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = OFF;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET QUERY_OPTIMIZER_HOTFIXES = PRIMARY;
GO
USE [gitea]
GO
/****** Object:  Table [dbo].[access]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[access](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NULL,
	[repo_id] [bigint] NULL,
	[mode] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[access_token]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[access_token](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NULL,
	[name] [varchar](255) NULL,
	[sha1] [varchar](40) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[action]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[action](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NULL,
	[op_type] [int] NULL,
	[act_user_id] [bigint] NULL,
	[repo_id] [bigint] NULL,
	[comment_id] [bigint] NULL,
	[is_deleted] [bit] NOT NULL,
	[ref_name] [varchar](255) NULL,
	[is_private] [bit] NOT NULL,
	[content] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[attachment]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[attachment](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uuid] [varchar](40) NULL,
	[issue_id] [bigint] NULL,
	[release_id] [bigint] NULL,
	[comment_id] [bigint] NULL,
	[name] [varchar](255) NULL,
	[download_count] [bigint] NULL,
	[size] [bigint] NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[collaboration]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[collaboration](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NOT NULL,
	[user_id] [bigint] NOT NULL,
	[mode] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[comment]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[comment](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [int] NULL,
	[poster_id] [bigint] NULL,
	[issue_id] [bigint] NULL,
	[label_id] [bigint] NULL,
	[old_milestone_id] [bigint] NULL,
	[milestone_id] [bigint] NULL,
	[assignee_id] [bigint] NULL,
	[removed_assignee] [bit] NULL,
	[old_title] [varchar](255) NULL,
	[new_title] [varchar](255) NULL,
	[dependent_issue_id] [bigint] NULL,
	[commit_id] [bigint] NULL,
	[line] [bigint] NULL,
	[tree_path] [varchar](255) NULL,
	[content] [varchar](max) NULL,
	[patch] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
	[commit_sha] [varchar](40) NULL,
	[review_id] [bigint] NULL,
	[invalidated] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[commit_status]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[commit_status](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[index] [bigint] NULL,
	[repo_id] [bigint] NULL,
	[state] [varchar](7) NOT NULL,
	[sha] [varchar](64) NOT NULL,
	[target_url] [varchar](max) NULL,
	[description] [varchar](max) NULL,
	[context] [varchar](max) NULL,
	[creator_id] [bigint] NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[deleted_branch]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[deleted_branch](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NOT NULL,
	[name] [varchar](255) NOT NULL,
	[commit] [varchar](255) NOT NULL,
	[deleted_by_id] [bigint] NULL,
	[deleted_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[deploy_key]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[deploy_key](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[key_id] [bigint] NULL,
	[repo_id] [bigint] NULL,
	[name] [varchar](255) NULL,
	[fingerprint] [varchar](255) NULL,
	[mode] [int] NOT NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[email_address]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[email_address](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NOT NULL,
	[email] [varchar](255) NOT NULL,
	[is_activated] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[external_login_user]    Script Date: 05/05/2019 11:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[external_login_user](
	[external_id] [varchar](255) NOT NULL,
	[user_id] [bigint] NOT NULL,
	[login_source_id] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[external_id] ASC,
	[login_source_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[follow]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[follow](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NULL,
	[follow_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[gpg_key]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[gpg_key](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner_id] [bigint] NOT NULL,
	[key_id] [char](16) NOT NULL,
	[primary_key_id] [char](16) NULL,
	[content] [varchar](max) NOT NULL,
	[created_unix] [bigint] NULL,
	[expired_unix] [bigint] NULL,
	[added_unix] [bigint] NULL,
	[emails] [varchar](max) NULL,
	[can_sign] [bit] NULL,
	[can_encrypt_comms] [bit] NULL,
	[can_encrypt_storage] [bit] NULL,
	[can_certify] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[hook_task]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[hook_task](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[hook_id] [bigint] NULL,
	[uuid] [varchar](255) NULL,
	[type] [int] NULL,
	[url] [varchar](max) NULL,
	[payload_content] [varchar](max) NULL,
	[content_type] [int] NULL,
	[event_type] [varchar](255) NULL,
	[is_ssl] [bit] NULL,
	[is_delivered] [bit] NULL,
	[delivered] [bigint] NULL,
	[is_succeed] [bit] NULL,
	[request_content] [varchar](max) NULL,
	[response_content] [varchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[issue]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[issue](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[index] [bigint] NULL,
	[poster_id] [bigint] NULL,
	[name] [varchar](255) NULL,
	[content] [varchar](max) NULL,
	[milestone_id] [bigint] NULL,
	[priority] [int] NULL,
	[is_closed] [bit] NULL,
	[is_pull] [bit] NULL,
	[num_comments] [int] NULL,
	[ref] [varchar](255) NULL,
	[deadline_unix] [bigint] NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
	[closed_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[issue_assignees]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[issue_assignees](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[assignee_id] [bigint] NULL,
	[issue_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[issue_dependency]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[issue_dependency](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NOT NULL,
	[issue_id] [bigint] NOT NULL,
	[dependency_id] [bigint] NOT NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[issue_label]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[issue_label](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[issue_id] [bigint] NULL,
	[label_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[issue_user]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[issue_user](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NULL,
	[issue_id] [bigint] NULL,
	[is_read] [bit] NULL,
	[is_mentioned] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[issue_watch]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[issue_watch](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NOT NULL,
	[issue_id] [bigint] NOT NULL,
	[is_watching] [bit] NOT NULL,
	[created_unix] [bigint] NOT NULL,
	[updated_unix] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[label]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[label](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[name] [varchar](255) NULL,
	[description] [varchar](255) NULL,
	[color] [varchar](7) NULL,
	[num_issues] [int] NULL,
	[num_closed_issues] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[lfs_lock]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[lfs_lock](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NOT NULL,
	[owner_id] [bigint] NOT NULL,
	[path] [varchar](max) NULL,
	[created] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[lfs_meta_object]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[lfs_meta_object](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[oid] [varchar](255) NOT NULL,
	[size] [bigint] NOT NULL,
	[repository_id] [bigint] NOT NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[login_source]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[login_source](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [int] NULL,
	[name] [varchar](255) NULL,
	[is_actived] [bit] NOT NULL,
	[is_sync_enabled] [bit] NOT NULL,
	[cfg] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[milestone]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[milestone](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[name] [varchar](255) NULL,
	[content] [varchar](max) NULL,
	[is_closed] [bit] NULL,
	[num_issues] [int] NULL,
	[num_closed_issues] [int] NULL,
	[completeness] [int] NULL,
	[deadline_unix] [bigint] NULL,
	[closed_date_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[mirror]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[mirror](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[interval] [bigint] NULL,
	[enable_prune] [bit] NOT NULL,
	[updated_unix] [bigint] NULL,
	[next_update_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[notice]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[notice](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [int] NULL,
	[description] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[notification]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[notification](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NOT NULL,
	[repo_id] [bigint] NOT NULL,
	[status] [smallint] NOT NULL,
	[source] [smallint] NOT NULL,
	[issue_id] [bigint] NOT NULL,
	[commit_id] [varchar](255) NULL,
	[updated_by] [bigint] NOT NULL,
	[created_unix] [bigint] NOT NULL,
	[updated_unix] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[oauth2_session]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[oauth2_session](
	[id] [varchar](100) NOT NULL,
	[data] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
	[expires_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[org_user]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[org_user](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NULL,
	[org_id] [bigint] NULL,
	[is_public] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[protected_branch]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[protected_branch](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[branch_name] [varchar](255) NULL,
	[can_push] [bit] NOT NULL,
	[enable_whitelist] [bit] NULL,
	[whitelist_user_i_ds] [varchar](max) NULL,
	[whitelist_team_i_ds] [varchar](max) NULL,
	[enable_merge_whitelist] [bit] NOT NULL,
	[merge_whitelist_user_i_ds] [varchar](max) NULL,
	[merge_whitelist_team_i_ds] [varchar](max) NULL,
	[approvals_whitelist_user_i_ds] [varchar](max) NULL,
	[approvals_whitelist_team_i_ds] [varchar](max) NULL,
	[required_approvals] [bigint] NOT NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[public_key]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[public_key](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner_id] [bigint] NOT NULL,
	[name] [varchar](255) NOT NULL,
	[fingerprint] [varchar](255) NOT NULL,
	[content] [varchar](max) NOT NULL,
	[mode] [int] NOT NULL,
	[type] [int] NOT NULL,
	[login_source_id] [bigint] NOT NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[pull_request]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[pull_request](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [int] NULL,
	[status] [int] NULL,
	[issue_id] [bigint] NULL,
	[index] [bigint] NULL,
	[head_repo_id] [bigint] NULL,
	[base_repo_id] [bigint] NULL,
	[head_user_name] [varchar](255) NULL,
	[head_branch] [varchar](255) NULL,
	[base_branch] [varchar](255) NULL,
	[merge_base] [varchar](40) NULL,
	[has_merged] [bit] NULL,
	[merged_commit_id] [varchar](40) NULL,
	[merger_id] [bigint] NULL,
	[merged_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[reaction]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[reaction](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [varchar](255) NOT NULL,
	[issue_id] [bigint] NOT NULL,
	[comment_id] [bigint] NULL,
	[user_id] [bigint] NOT NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[release]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[release](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[publisher_id] [bigint] NULL,
	[tag_name] [varchar](255) NULL,
	[lower_tag_name] [varchar](255) NULL,
	[target] [varchar](255) NULL,
	[title] [varchar](255) NULL,
	[sha1] [varchar](40) NULL,
	[num_commits] [bigint] NULL,
	[note] [varchar](max) NULL,
	[is_draft] [bit] NOT NULL,
	[is_prerelease] [bit] NOT NULL,
	[is_tag] [bit] NOT NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[repo_indexer_status]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[repo_indexer_status](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[commit_sha] [varchar](40) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[repo_redirect]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[repo_redirect](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner_id] [bigint] NULL,
	[lower_name] [varchar](255) NOT NULL,
	[redirect_repo_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[repo_topic]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[repo_topic](
	[repo_id] [bigint] NULL,
	[topic_id] [bigint] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[repo_unit]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[repo_unit](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[type] [int] NULL,
	[config] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[repository]    Script Date: 05/05/2019 11:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[repository](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner_id] [bigint] NULL,
	[lower_name] [varchar](255) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[description] [varchar](255) NULL,
	[website] [varchar](255) NULL,
	[default_branch] [varchar](255) NULL,
	[num_watches] [int] NULL,
	[num_stars] [int] NULL,
	[num_forks] [int] NULL,
	[num_issues] [int] NULL,
	[num_closed_issues] [int] NULL,
	[num_pulls] [int] NULL,
	[num_closed_pulls] [int] NULL,
	[num_milestones] [int] NOT NULL,
	[num_closed_milestones] [int] NOT NULL,
	[is_private] [bit] NULL,
	[is_bare] [bit] NULL,
	[is_mirror] [bit] NULL,
	[is_fork] [bit] NOT NULL,
	[fork_id] [bigint] NULL,
	[size] [bigint] NOT NULL,
	[is_fsck_enabled] [bit] NOT NULL,
	[topics] [varchar](max) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[review]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[review](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[type] [int] NULL,
	[reviewer_id] [bigint] NULL,
	[issue_id] [bigint] NULL,
	[content] [varchar](255) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[star]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[star](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NULL,
	[repo_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[stopwatch]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stopwatch](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[issue_id] [bigint] NULL,
	[user_id] [bigint] NULL,
	[created_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[team]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[team](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[org_id] [bigint] NULL,
	[lower_name] [varchar](255) NULL,
	[name] [varchar](255) NULL,
	[description] [varchar](255) NULL,
	[authorize] [int] NULL,
	[num_repos] [int] NULL,
	[num_members] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[team_repo]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[team_repo](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[org_id] [bigint] NULL,
	[team_id] [bigint] NULL,
	[repo_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[team_unit]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[team_unit](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[org_id] [bigint] NULL,
	[team_id] [bigint] NULL,
	[type] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[team_user]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[team_user](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[org_id] [bigint] NULL,
	[team_id] [bigint] NULL,
	[uid] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[topic]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[topic](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[name] [varchar](25) NULL,
	[repo_count] [int] NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tracked_time]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tracked_time](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[issue_id] [bigint] NULL,
	[user_id] [bigint] NULL,
	[created_unix] [bigint] NULL,
	[time] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[two_factor]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[two_factor](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NULL,
	[secret] [varchar](255) NULL,
	[scratch_salt] [varchar](255) NULL,
	[scratch_hash] [varchar](255) NULL,
	[last_used_passcode] [varchar](10) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[u2f_registration]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[u2f_registration](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[name] [varchar](255) NULL,
	[user_id] [bigint] NULL,
	[raw] [varbinary](50) NULL,
	[counter] [int] NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[upload]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[upload](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uuid] [varchar](40) NULL,
	[name] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[user]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[user](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[lower_name] [varchar](255) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[full_name] [varchar](255) NULL,
	[email] [varchar](255) NOT NULL,
	[keep_email_private] [bit] NULL,
	[passwd] [varchar](255) NOT NULL,
	[must_change_password] [bit] NOT NULL,
	[login_type] [int] NULL,
	[login_source] [bigint] NOT NULL,
	[login_name] [varchar](255) NULL,
	[type] [int] NULL,
	[location] [varchar](255) NULL,
	[website] [varchar](255) NULL,
	[rands] [varchar](10) NULL,
	[salt] [varchar](10) NULL,
	[language] [varchar](5) NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
	[last_login_unix] [bigint] NULL,
	[last_repo_visibility] [bit] NULL,
	[max_repo_creation] [int] NOT NULL,
	[is_active] [bit] NULL,
	[is_admin] [bit] NULL,
	[allow_git_hook] [bit] NULL,
	[allow_import_local] [bit] NULL,
	[allow_create_organization] [bit] NULL,
	[prohibit_login] [bit] NOT NULL,
	[avatar] [varchar](2048) NOT NULL,
	[avatar_email] [varchar](255) NOT NULL,
	[use_custom_avatar] [bit] NULL,
	[num_followers] [int] NULL,
	[num_following] [int] NOT NULL,
	[num_stars] [int] NULL,
	[num_repos] [int] NULL,
	[description] [varchar](255) NULL,
	[num_teams] [int] NULL,
	[num_members] [int] NULL,
	[diff_view_style] [varchar](255) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[user_open_id]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[user_open_id](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [bigint] NOT NULL,
	[uri] [varchar](255) NOT NULL,
	[show] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[version]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[version](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[version] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[watch]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[watch](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [bigint] NULL,
	[repo_id] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[webhook]    Script Date: 05/05/2019 11:33:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[webhook](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[repo_id] [bigint] NULL,
	[org_id] [bigint] NULL,
	[url] [varchar](max) NULL,
	[content_type] [int] NULL,
	[secret] [varchar](max) NULL,
	[events] [varchar](max) NULL,
	[is_ssl] [bit] NULL,
	[is_active] [bit] NULL,
	[hook_task_type] [int] NULL,
	[meta] [varchar](max) NULL,
	[last_status] [int] NULL,
	[created_unix] [bigint] NULL,
	[updated_unix] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[access] ON 

INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (1, 2, 3, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (2, 4, 4, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (3, 4, 3, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (4, 15, 22, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (5, 15, 21, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (6, 15, 23, 4)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (7, 15, 24, 4)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (8, 18, 23, 4)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (9, 18, 24, 4)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (10, 18, 22, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (11, 18, 21, 2)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (12, 20, 27, 4)
INSERT [dbo].[access] ([id], [user_id], [repo_id], [mode]) VALUES (13, 20, 28, 4)
SET IDENTITY_INSERT [dbo].[access] OFF
SET IDENTITY_INSERT [dbo].[access_token] ON 
INSERT [dbo].[access_token] ([id], [uid], [name], [sha1], [created_unix], [updated_unix]) VALUES (1, 1, N'Token A', N'd2c6c1ba3890b309189a8e618c72a162e4efbf36', 946687980, 946687980)
INSERT [dbo].[access_token] ([id], [uid], [name], [sha1], [created_unix], [updated_unix]) VALUES (2, 1, N'Token B', N'4c6f36e6cf498e2a448662f915d932c09c5a146c', 946687980, 946687980)
INSERT [dbo].[access_token] ([id], [uid], [name], [sha1], [created_unix], [updated_unix]) VALUES (3, 2, N'Token A', N'90a18faa671dc43924b795806ffe4fd169d28c91', 946687980, 946687980)
INSERT [dbo].[access_token] ([id], [uid], [name], [sha1], [created_unix], [updated_unix]) VALUES (4, 1, N'api-testing-token', N'13d60dd7204f2689c42ce8b3be5908ef0a4868fc', 1557054214, 1557054215)
SET IDENTITY_INSERT [dbo].[access_token] OFF
SET IDENTITY_INSERT [dbo].[action] ON 

INSERT [dbo].[action] ([id], [user_id], [op_type], [act_user_id], [repo_id], [comment_id], [is_deleted], [ref_name], [is_private], [content], [created_unix]) VALUES (1, 2, 12, 2, 2, NULL, 0, NULL, 1, NULL, 1540139562)
INSERT [dbo].[action] ([id], [user_id], [op_type], [act_user_id], [repo_id], [comment_id], [is_deleted], [ref_name], [is_private], [content], [created_unix]) VALUES (2, 3, 2, 2, 3, NULL, 0, NULL, 1, N'oldRepoName', NULL)
INSERT [dbo].[action] ([id], [user_id], [op_type], [act_user_id], [repo_id], [comment_id], [is_deleted], [ref_name], [is_private], [content], [created_unix]) VALUES (3, 11, 1, 11, 9, NULL, 0, NULL, 0, NULL, NULL)
SET IDENTITY_INSERT [dbo].[action] OFF
SET IDENTITY_INSERT [dbo].[attachment] ON 

INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (1, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 1, NULL, 0, N'attach1', 0, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (2, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 1, NULL, 0, N'attach2', 1, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (3, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 2, NULL, 1, N'attach1', 0, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (4, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 3, NULL, 1, N'attach2', 1, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (5, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 4, NULL, 0, N'attach1', 0, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (6, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 5, NULL, 2, N'attach1', 0, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (7, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 5, NULL, 2, N'attach1', 0, 0, 946684800)
INSERT [dbo].[attachment] ([id], [uuid], [issue_id], [release_id], [comment_id], [name], [download_count], [size], [created_unix]) VALUES (8, N'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 6, NULL, 0, N'attach1', 0, 0, 946684800)
SET IDENTITY_INSERT [dbo].[attachment] OFF
SET IDENTITY_INSERT [dbo].[collaboration] ON 

INSERT [dbo].[collaboration] ([id], [repo_id], [user_id], [mode]) VALUES (1, 3, 2, 2)
INSERT [dbo].[collaboration] ([id], [repo_id], [user_id], [mode]) VALUES (2, 4, 4, 2)
SET IDENTITY_INSERT [dbo].[collaboration] OFF
SET IDENTITY_INSERT [dbo].[comment] ON 

INSERT [dbo].[comment] ([id], [type], [poster_id], [issue_id], [label_id], [old_milestone_id], [milestone_id], [assignee_id], [removed_assignee], [old_title], [new_title], [dependent_issue_id], [commit_id], [line], [tree_path], [content], [patch], [created_unix], [updated_unix], [commit_sha], [review_id], [invalidated]) VALUES (1, 7, 2, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, 946684810, NULL, NULL, NULL, NULL)
INSERT [dbo].[comment] ([id], [type], [poster_id], [issue_id], [label_id], [old_milestone_id], [milestone_id], [assignee_id], [removed_assignee], [old_title], [new_title], [dependent_issue_id], [commit_id], [line], [tree_path], [content], [patch], [created_unix], [updated_unix], [commit_sha], [review_id], [invalidated]) VALUES (2, 0, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'good work!', NULL, 946684811, NULL, NULL, NULL, NULL)
INSERT [dbo].[comment] ([id], [type], [poster_id], [issue_id], [label_id], [old_milestone_id], [milestone_id], [assignee_id], [removed_assignee], [old_title], [new_title], [dependent_issue_id], [commit_id], [line], [tree_path], [content], [patch], [created_unix], [updated_unix], [commit_sha], [review_id], [invalidated]) VALUES (3, 0, 5, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'meh...', NULL, 946684812, NULL, NULL, NULL, NULL)
INSERT [dbo].[comment] ([id], [type], [poster_id], [issue_id], [label_id], [old_milestone_id], [milestone_id], [assignee_id], [removed_assignee], [old_title], [new_title], [dependent_issue_id], [commit_id], [line], [tree_path], [content], [patch], [created_unix], [updated_unix], [commit_sha], [review_id], [invalidated]) VALUES (4, 21, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, N'README.md', N'meh...', NULL, 946684812, NULL, NULL, 4, 0)
INSERT [dbo].[comment] ([id], [type], [poster_id], [issue_id], [label_id], [old_milestone_id], [milestone_id], [assignee_id], [removed_assignee], [old_title], [new_title], [dependent_issue_id], [commit_id], [line], [tree_path], [content], [patch], [created_unix], [updated_unix], [commit_sha], [review_id], [invalidated]) VALUES (5, 21, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, -4, N'README.md', N'meh...', NULL, 946684812, NULL, NULL, NULL, 0)
INSERT [dbo].[comment] ([id], [type], [poster_id], [issue_id], [label_id], [old_milestone_id], [milestone_id], [assignee_id], [removed_assignee], [old_title], [new_title], [dependent_issue_id], [commit_id], [line], [tree_path], [content], [patch], [created_unix], [updated_unix], [commit_sha], [review_id], [invalidated]) VALUES (6, 21, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, -4, N'README.md', N'it''s already invalidated. boring...', NULL, 946684812, NULL, NULL, NULL, 1)
SET IDENTITY_INSERT [dbo].[comment] OFF
SET IDENTITY_INSERT [dbo].[commit_status] ON 

INSERT [dbo].[commit_status] ([id], [index], [repo_id], [state], [sha], [target_url], [description], [context], [creator_id], [created_unix], [updated_unix]) VALUES (1, 1, 1, N'pending', N'1234123412341234123412341234123412341234', N'https://example.com/builds/', N'My awesome CI-service', N'ci/awesomeness', 2, NULL, NULL)
INSERT [dbo].[commit_status] ([id], [index], [repo_id], [state], [sha], [target_url], [description], [context], [creator_id], [created_unix], [updated_unix]) VALUES (2, 2, 1, N'warning', N'1234123412341234123412341234123412341234', N'https://example.com/converage/', N'My awesome Coverage service', N'cov/awesomeness', 2, NULL, NULL)
INSERT [dbo].[commit_status] ([id], [index], [repo_id], [state], [sha], [target_url], [description], [context], [creator_id], [created_unix], [updated_unix]) VALUES (3, 3, 1, N'success', N'1234123412341234123412341234123412341234', N'https://example.com/converage/', N'My awesome Coverage service', N'cov/awesomeness', 2, NULL, NULL)
INSERT [dbo].[commit_status] ([id], [index], [repo_id], [state], [sha], [target_url], [description], [context], [creator_id], [created_unix], [updated_unix]) VALUES (4, 4, 1, N'failure', N'1234123412341234123412341234123412341234', N'https://example.com/builds/', N'My awesome CI-service', N'ci/awesomeness', 2, NULL, NULL)
INSERT [dbo].[commit_status] ([id], [index], [repo_id], [state], [sha], [target_url], [description], [context], [creator_id], [created_unix], [updated_unix]) VALUES (5, 5, 1, N'error', N'1234123412341234123412341234123412341234', N'https://example.com/builds/', N'My awesome deploy service', N'deploy/awesomeness', 2, NULL, NULL)
SET IDENTITY_INSERT [dbo].[commit_status] OFF
SET IDENTITY_INSERT [dbo].[deleted_branch] ON 

INSERT [dbo].[deleted_branch] ([id], [repo_id], [name], [commit], [deleted_by_id], [deleted_unix]) VALUES (1, 1, N'foo', N'1.21321e+024', 1, 978307200)
INSERT [dbo].[deleted_branch] ([id], [repo_id], [name], [commit], [deleted_by_id], [deleted_unix]) VALUES (2, 1, N'bar', N'5.65546e+024', 99, 978307200)
SET IDENTITY_INSERT [dbo].[deleted_branch] OFF
SET IDENTITY_INSERT [dbo].[email_address] ON 

INSERT [dbo].[email_address] ([id], [uid], [email], [is_activated]) VALUES (1, 1, N'user11@example.com', 0)
INSERT [dbo].[email_address] ([id], [uid], [email], [is_activated]) VALUES (2, 1, N'user12@example.com', 0)
INSERT [dbo].[email_address] ([id], [uid], [email], [is_activated]) VALUES (3, 2, N'user2@example.com', 1)
INSERT [dbo].[email_address] ([id], [uid], [email], [is_activated]) VALUES (4, 2, N'user21@example.com', 0)
INSERT [dbo].[email_address] ([id], [uid], [email], [is_activated]) VALUES (5, 9999999, N'user9999999@example.com', 1)
INSERT [dbo].[email_address] ([id], [uid], [email], [is_activated]) VALUES (6, 10, N'user101@example.com', 1)
SET IDENTITY_INSERT [dbo].[email_address] OFF
SET IDENTITY_INSERT [dbo].[follow] ON 

INSERT [dbo].[follow] ([id], [user_id], [follow_id]) VALUES (3, 2, 8)
INSERT [dbo].[follow] ([id], [user_id], [follow_id]) VALUES (1, 4, 2)
INSERT [dbo].[follow] ([id], [user_id], [follow_id]) VALUES (2, 8, 2)
SET IDENTITY_INSERT [dbo].[follow] OFF
SET IDENTITY_INSERT [dbo].[hook_task] ON 

INSERT [dbo].[hook_task] ([id], [repo_id], [hook_id], [uuid], [type], [url], [payload_content], [content_type], [event_type], [is_ssl], [is_delivered], [delivered], [is_succeed], [request_content], [response_content]) VALUES (1, 1, 1, N'uuid1', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL)
SET IDENTITY_INSERT [dbo].[hook_task] OFF
SET IDENTITY_INSERT [dbo].[issue] ON 

INSERT [dbo].[issue] ([id], [repo_id], [index], [poster_id], [name], [content], [milestone_id], [priority], [is_closed], [is_pull], [num_comments], [ref], [deadline_unix], [created_unix], [updated_unix], [closed_unix]) VALUES (1, 1, 1, 1, N'issue1', N'content for the first issue', NULL, NULL, 0, 0, 2, NULL, NULL, 946684800, 978307200, NULL)
INSERT [dbo].[issue] ([id], [repo_id], [index], [poster_id], [name], [content], [milestone_id], [priority], [is_closed], [is_pull], [num_comments], [ref], [deadline_unix], [created_unix], [updated_unix], [closed_unix]) VALUES (2, 1, 2, 1, N'issue2', N'content for the second issue', 1, NULL, 0, 1, NULL, NULL, NULL, 946684810, 978307190, NULL)
INSERT [dbo].[issue] ([id], [repo_id], [index], [poster_id], [name], [content], [milestone_id], [priority], [is_closed], [is_pull], [num_comments], [ref], [deadline_unix], [created_unix], [updated_unix], [closed_unix]) VALUES (3, 1, 3, 1, N'issue3', N'content for the third issue', NULL, NULL, 0, 1, NULL, NULL, NULL, 946684820, 978307180, NULL)
INSERT [dbo].[issue] ([id], [repo_id], [index], [poster_id], [name], [content], [milestone_id], [priority], [is_closed], [is_pull], [num_comments], [ref], [deadline_unix], [created_unix], [updated_unix], [closed_unix]) VALUES (4, 2, 1, 2, N'issue4', N'content for the fourth issue', NULL, NULL, 1, 0, NULL, NULL, NULL, 946684830, 978307200, NULL)
INSERT [dbo].[issue] ([id], [repo_id], [index], [poster_id], [name], [content], [milestone_id], [priority], [is_closed], [is_pull], [num_comments], [ref], [deadline_unix], [created_unix], [updated_unix], [closed_unix]) VALUES (5, 1, 4, 2, N'issue5', N'content for the fifth issue', NULL, NULL, 1, 0, NULL, NULL, NULL, 946684840, 978307200, NULL)
INSERT [dbo].[issue] ([id], [repo_id], [index], [poster_id], [name], [content], [milestone_id], [priority], [is_closed], [is_pull], [num_comments], [ref], [deadline_unix], [created_unix], [updated_unix], [closed_unix]) VALUES (6, 3, 1, 1, N'issue6', N'content6', NULL, NULL, 0, 0, 0, NULL, NULL, 946684850, 978307200, NULL)
SET IDENTITY_INSERT [dbo].[issue] OFF
SET IDENTITY_INSERT [dbo].[issue_assignees] ON 

INSERT [dbo].[issue_assignees] ([id], [assignee_id], [issue_id]) VALUES (1, 1, 1)
INSERT [dbo].[issue_assignees] ([id], [assignee_id], [issue_id]) VALUES (2, 1, 6)
SET IDENTITY_INSERT [dbo].[issue_assignees] OFF
SET IDENTITY_INSERT [dbo].[issue_label] ON 

INSERT [dbo].[issue_label] ([id], [issue_id], [label_id]) VALUES (1, 1, 1)
INSERT [dbo].[issue_label] ([id], [issue_id], [label_id]) VALUES (3, 2, 1)
INSERT [dbo].[issue_label] ([id], [issue_id], [label_id]) VALUES (2, 5, 2)
SET IDENTITY_INSERT [dbo].[issue_label] OFF
SET IDENTITY_INSERT [dbo].[issue_user] ON 

INSERT [dbo].[issue_user] ([id], [uid], [issue_id], [is_read], [is_mentioned]) VALUES (1, 1, 1, 1, 0)
INSERT [dbo].[issue_user] ([id], [uid], [issue_id], [is_read], [is_mentioned]) VALUES (2, 2, 1, 1, 0)
INSERT [dbo].[issue_user] ([id], [uid], [issue_id], [is_read], [is_mentioned]) VALUES (3, 4, 1, 0, 0)
SET IDENTITY_INSERT [dbo].[issue_user] OFF
SET IDENTITY_INSERT [dbo].[issue_watch] ON 

INSERT [dbo].[issue_watch] ([id], [user_id], [issue_id], [is_watching], [created_unix], [updated_unix]) VALUES (1, 9, 1, 1, 946684800, 946684800)
INSERT [dbo].[issue_watch] ([id], [user_id], [issue_id], [is_watching], [created_unix], [updated_unix]) VALUES (2, 2, 2, 0, 946684800, 946684800)
SET IDENTITY_INSERT [dbo].[issue_watch] OFF
SET IDENTITY_INSERT [dbo].[label] ON 

INSERT [dbo].[label] ([id], [repo_id], [name], [description], [color], [num_issues], [num_closed_issues]) VALUES (1, 1, N'label1', NULL, N'#abcdef', 2, 0)
INSERT [dbo].[label] ([id], [repo_id], [name], [description], [color], [num_issues], [num_closed_issues]) VALUES (2, 1, N'label2', NULL, N'#000000', 1, 1)
SET IDENTITY_INSERT [dbo].[label] OFF
SET IDENTITY_INSERT [dbo].[milestone] ON 

INSERT [dbo].[milestone] ([id], [repo_id], [name], [content], [is_closed], [num_issues], [num_closed_issues], [completeness], [deadline_unix], [closed_date_unix]) VALUES (1, 1, N'milestone1', N'content1', 0, 1, NULL, NULL, NULL, NULL)
INSERT [dbo].[milestone] ([id], [repo_id], [name], [content], [is_closed], [num_issues], [num_closed_issues], [completeness], [deadline_unix], [closed_date_unix]) VALUES (2, 1, N'milestone2', N'content2', 0, 0, NULL, NULL, NULL, NULL)
SET IDENTITY_INSERT [dbo].[milestone] OFF
SET IDENTITY_INSERT [dbo].[notice] ON 

INSERT [dbo].[notice] ([id], [type], [description], [created_unix]) VALUES (1, 1, N'description1', NULL)
INSERT [dbo].[notice] ([id], [type], [description], [created_unix]) VALUES (2, 1, N'description2', NULL)
INSERT [dbo].[notice] ([id], [type], [description], [created_unix]) VALUES (3, 1, N'description3', NULL)
SET IDENTITY_INSERT [dbo].[notice] OFF
SET IDENTITY_INSERT [dbo].[notification] ON 

INSERT [dbo].[notification] ([id], [user_id], [repo_id], [status], [source], [issue_id], [commit_id], [updated_by], [created_unix], [updated_unix]) VALUES (1, 1, 1, 1, 1, 1, NULL, 2, 946684800, 946684800)
INSERT [dbo].[notification] ([id], [user_id], [repo_id], [status], [source], [issue_id], [commit_id], [updated_by], [created_unix], [updated_unix]) VALUES (2, 2, 1, 2, 1, 2, NULL, 1, 946684800, 946684800)
INSERT [dbo].[notification] ([id], [user_id], [repo_id], [status], [source], [issue_id], [commit_id], [updated_by], [created_unix], [updated_unix]) VALUES (3, 2, 1, 3, 1, 2, NULL, 1, 946684800, 946684800)
INSERT [dbo].[notification] ([id], [user_id], [repo_id], [status], [source], [issue_id], [commit_id], [updated_by], [created_unix], [updated_unix]) VALUES (4, 2, 1, 1, 1, 2, NULL, 1, 946684800, 946684800)
SET IDENTITY_INSERT [dbo].[notification] OFF
SET IDENTITY_INSERT [dbo].[org_user] ON 

INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (1, 2, 3, 1)
INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (2, 4, 3, 0)
INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (3, 5, 6, 1)
INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (4, 5, 7, 0)
INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (5, 15, 17, 1)
INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (6, 18, 17, 0)
INSERT [dbo].[org_user] ([id], [uid], [org_id], [is_public]) VALUES (7, 20, 19, 1)
SET IDENTITY_INSERT [dbo].[org_user] OFF
SET IDENTITY_INSERT [dbo].[pull_request] ON 

INSERT [dbo].[pull_request] ([id], [type], [status], [issue_id], [index], [head_repo_id], [base_repo_id], [head_user_name], [head_branch], [base_branch], [merge_base], [has_merged], [merged_commit_id], [merger_id], [merged_unix]) VALUES (1, 0, 2, 2, 2, 1, 1, N'user1', N'branch1', N'master', N'1234567890abcdef', 1, NULL, 2, NULL)
INSERT [dbo].[pull_request] ([id], [type], [status], [issue_id], [index], [head_repo_id], [base_repo_id], [head_user_name], [head_branch], [base_branch], [merge_base], [has_merged], [merged_commit_id], [merger_id], [merged_unix]) VALUES (2, 0, 2, 3, 3, 1, 1, N'user1', N'branch2', N'master', N'fedcba9876543210', 0, NULL, NULL, NULL)
SET IDENTITY_INSERT [dbo].[pull_request] OFF
SET IDENTITY_INSERT [dbo].[repo_redirect] ON 

INSERT [dbo].[repo_redirect] ([id], [owner_id], [lower_name], [redirect_repo_id]) VALUES (1, 2, N'oldrepo1', 1)
SET IDENTITY_INSERT [dbo].[repo_redirect] OFF
INSERT [dbo].[repo_topic] ([repo_id], [topic_id]) VALUES (1, 1)
INSERT [dbo].[repo_topic] ([repo_id], [topic_id]) VALUES (1, 2)
INSERT [dbo].[repo_topic] ([repo_id], [topic_id]) VALUES (1, 3)
INSERT [dbo].[repo_topic] ([repo_id], [topic_id]) VALUES (33, 1)
INSERT [dbo].[repo_topic] ([repo_id], [topic_id]) VALUES (33, 4)
SET IDENTITY_INSERT [dbo].[repo_unit] ON 

INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (1, 1, 4, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (2, 1, 5, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (3, 1, 1, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (4, 1, 2, N'{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (5, 1, 3, N'{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (6, 3, 1, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (7, 3, 2, N'{"EnableTimetracker":false,"AllowOnlyContributorsToTrackTime":false}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (8, 3, 3, N'{"IgnoreWhitespaceConflicts":true,"AllowMerge":true,"AllowRebase":false,"AllowRebaseMerge":true,"AllowSquash":false}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (9, 3, 4, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (10, 3, 5, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (11, 31, 1, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (12, 33, 1, N'{}', 1535593231)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (13, 33, 2, N'{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 1535593231)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (14, 33, 3, N'{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowSquash":true}', 1535593231)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (15, 33, 4, N'{}', 1535593231)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (16, 33, 5, N'{}', 1535593231)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (17, 4, 4, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (18, 4, 5, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (19, 4, 1, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (20, 4, 2, N'{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (21, 4, 3, N'{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowSquash":true}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (22, 2, 4, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (23, 2, 5, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (24, 2, 1, N'{}', 946684810)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (25, 32, 1, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (26, 32, 2, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (27, 24, 1, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (28, 24, 2, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (29, 16, 1, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (30, 23, 1, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (31, 27, 1, N'{}', 1524304355)
INSERT [dbo].[repo_unit] ([id], [repo_id], [type], [config], [created_unix]) VALUES (32, 28, 1, N'{}', 1524304355)
SET IDENTITY_INSERT [dbo].[repo_unit] OFF
SET IDENTITY_INSERT [dbo].[repository] ON 

INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (1, 2, N'repo1', N'repo1', NULL, NULL, NULL, 3, NULL, NULL, 2, 1, 2, 0, 2, 0, 0, NULL, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (2, 2, N'repo2', N'repo2', NULL, NULL, NULL, NULL, 1, NULL, 1, 1, 0, 0, 0, 0, 1, NULL, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (3, 3, N'repo3', N'repo3', NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, 0, 0, 0, 1, NULL, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (4, 5, N'repo4', N'repo4', NULL, NULL, NULL, NULL, 1, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (5, 3, N'repo5', N'repo5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 1, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (6, 10, N'repo6', N'repo6', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (7, 10, N'repo7', N'repo7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (8, 10, N'repo8', N'repo8', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (9, 11, N'repo9', N'repo9', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (10, 12, N'repo10', N'repo10', NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (11, 13, N'repo11', N'repo11', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 10, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (12, 14, N'test_repo_12', N'test_repo_12', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (13, 14, N'test_repo_13', N'test_repo_13', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (14, 14, N'test_repo_14', N'test_repo_14', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (15, 2, N'repo15', N'repo15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 1, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (16, 2, N'repo16', N'repo16', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (17, 15, N'big_test_public_1', N'big_test_public_1', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (18, 15, N'big_test_public_2', N'big_test_public_2', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (19, 15, N'big_test_private_1', N'big_test_private_1', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (20, 15, N'big_test_private_2', N'big_test_private_2', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (21, 16, N'big_test_public_3', N'big_test_public_3', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (22, 16, N'big_test_private_3', N'big_test_private_3', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (23, 17, N'big_test_public_4', N'big_test_public_4', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (24, 17, N'big_test_private_4', N'big_test_private_4', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (25, 20, N'big_test_public_mirror_5', N'big_test_public_mirror_5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 1, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (26, 20, N'big_test_private_mirror_5', N'big_test_private_mirror_5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 1, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (27, 19, N'big_test_public_mirror_6', N'big_test_public_mirror_6', NULL, NULL, NULL, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, 1, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (28, 19, N'big_test_private_mirror_6', N'big_test_private_mirror_6', NULL, NULL, NULL, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 1, NULL, 1, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (29, 20, N'big_test_public_fork_7', N'big_test_public_fork_7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 1, 27, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (30, 20, N'big_test_private_fork_7', N'big_test_private_fork_7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, 0, 1, 28, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (31, 2, N'repo20', N'repo20', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (32, 3, N'repo21', N'repo21', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (33, 2, N'utf8', N'utf8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (34, 21, N'golang', N'golang', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
INSERT [dbo].[repository] ([id], [owner_id], [lower_name], [name], [description], [website], [default_branch], [num_watches], [num_stars], [num_forks], [num_issues], [num_closed_issues], [num_pulls], [num_closed_pulls], [num_milestones], [num_closed_milestones], [is_private], [is_bare], [is_mirror], [is_fork], [fork_id], [size], [is_fsck_enabled], [topics], [created_unix], [updated_unix]) VALUES (35, 21, N'graphql', N'graphql', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, 0, NULL, 0, 0, NULL, 0, 1, NULL, NULL, NULL)
SET IDENTITY_INSERT [dbo].[repository] OFF
SET IDENTITY_INSERT [dbo].[review] ON 

INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (1, 1, 1, 2, N'Demo Review', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (2, 1, 534543, 534543, N'Invalid Review #1', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (3, 1, 1, 343545, N'Invalid Review #2', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (4, 0, 1, 2, N'Pending Review', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (5, 2, 1, 3, N'New review 1', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (6, 0, 2, 3, N'New review 3', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (7, 3, 3, 3, N'New review 4', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (8, 1, 4, 3, N'New review 5', 946684810, 946684810)
INSERT [dbo].[review] ([id], [type], [reviewer_id], [issue_id], [content], [created_unix], [updated_unix]) VALUES (9, 3, 2, 3, N'New review 3 rejected', 946684810, 946684810)
SET IDENTITY_INSERT [dbo].[review] OFF
SET IDENTITY_INSERT [dbo].[star] ON 

INSERT [dbo].[star] ([id], [uid], [repo_id]) VALUES (1, 2, 2)
INSERT [dbo].[star] ([id], [uid], [repo_id]) VALUES (2, 2, 4)
SET IDENTITY_INSERT [dbo].[star] OFF
SET IDENTITY_INSERT [dbo].[stopwatch] ON 

INSERT [dbo].[stopwatch] ([id], [issue_id], [user_id], [created_unix]) VALUES (1, 1, 1, 1500988502)
INSERT [dbo].[stopwatch] ([id], [issue_id], [user_id], [created_unix]) VALUES (2, 2, 2, 1500988502)
SET IDENTITY_INSERT [dbo].[stopwatch] OFF
SET IDENTITY_INSERT [dbo].[team] ON 

INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (1, 3, N'owners', N'Owners', NULL, 4, 3, 1)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (2, 3, N'team1', N'team1', NULL, 2, 1, 2)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (3, 6, N'owners', N'Owners', NULL, 4, 0, 1)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (4, 7, N'owners', N'Owners', NULL, 4, 0, 1)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (5, 17, N'owners', N'Owners', NULL, 4, 2, 2)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (6, 19, N'owners', N'Owners', NULL, 4, 2, 1)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (7, 3, N'test_team', N'test_team', NULL, 2, 1, 1)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (8, 17, N'test_team', N'test_team', NULL, 2, 1, 1)
INSERT [dbo].[team] ([id], [org_id], [lower_name], [name], [description], [authorize], [num_repos], [num_members]) VALUES (9, 17, N'review_team', N'review_team', NULL, 1, 1, 1)
SET IDENTITY_INSERT [dbo].[team] OFF
SET IDENTITY_INSERT [dbo].[team_repo] ON 

INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (1, 3, 1, 3)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (2, 3, 2, 3)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (3, 3, 1, 5)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (4, 17, 5, 23)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (5, 17, 5, 24)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (6, 19, 6, 27)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (7, 19, 6, 28)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (8, 3, 1, 32)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (9, 3, 7, 32)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (10, 17, 8, 24)
INSERT [dbo].[team_repo] ([id], [org_id], [team_id], [repo_id]) VALUES (11, 17, 9, 24)
SET IDENTITY_INSERT [dbo].[team_repo] OFF
SET IDENTITY_INSERT [dbo].[team_unit] ON 

INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (1, NULL, 1, 1)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (2, NULL, 1, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (3, NULL, 1, 3)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (4, NULL, 1, 4)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (5, NULL, 1, 5)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (6, NULL, 1, 6)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (7, NULL, 1, 7)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (8, NULL, 2, 1)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (9, NULL, 2, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (10, NULL, 2, 3)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (11, NULL, 2, 4)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (12, NULL, 2, 5)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (13, NULL, 2, 6)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (14, NULL, 2, 7)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (15, NULL, 3, 1)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (16, NULL, 3, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (17, NULL, 3, 3)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (18, NULL, 3, 4)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (19, NULL, 3, 5)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (20, NULL, 3, 6)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (21, NULL, 3, 7)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (22, NULL, 4, 1)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (23, NULL, 4, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (24, NULL, 4, 3)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (25, NULL, 4, 4)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (26, NULL, 4, 5)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (27, NULL, 4, 6)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (28, NULL, 4, 7)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (29, NULL, 5, 1)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (30, NULL, 5, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (31, NULL, 5, 3)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (32, NULL, 5, 4)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (33, NULL, 5, 5)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (34, NULL, 5, 6)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (35, NULL, 5, 7)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (36, NULL, 6, 1)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (37, NULL, 6, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (38, NULL, 6, 3)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (39, NULL, 6, 4)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (40, NULL, 6, 5)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (41, NULL, 6, 6)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (42, NULL, 6, 7)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (43, NULL, 7, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (44, NULL, 8, 2)
INSERT [dbo].[team_unit] ([id], [org_id], [team_id], [type]) VALUES (45, NULL, 9, 1)
SET IDENTITY_INSERT [dbo].[team_unit] OFF
SET IDENTITY_INSERT [dbo].[team_user] ON 

INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (1, 3, 1, 2)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (2, 3, 2, 2)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (3, 3, 2, 4)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (4, 6, 3, 5)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (5, 7, 4, 5)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (6, 17, 5, 15)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (7, 17, 5, 18)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (8, 19, 6, 20)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (9, 3, 7, 15)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (10, 17, 8, 2)
INSERT [dbo].[team_user] ([id], [org_id], [team_id], [uid]) VALUES (11, 17, 9, 20)
SET IDENTITY_INSERT [dbo].[team_user] OFF
SET IDENTITY_INSERT [dbo].[topic] ON 

INSERT [dbo].[topic] ([id], [name], [repo_count], [created_unix], [updated_unix]) VALUES (1, N'golang', 2, NULL, NULL)
INSERT [dbo].[topic] ([id], [name], [repo_count], [created_unix], [updated_unix]) VALUES (2, N'database', 1, NULL, NULL)
INSERT [dbo].[topic] ([id], [name], [repo_count], [created_unix], [updated_unix]) VALUES (3, N'SQL', 1, NULL, NULL)
INSERT [dbo].[topic] ([id], [name], [repo_count], [created_unix], [updated_unix]) VALUES (4, N'graphql', 1, NULL, NULL)
SET IDENTITY_INSERT [dbo].[topic] OFF
SET IDENTITY_INSERT [dbo].[tracked_time] ON 

INSERT [dbo].[tracked_time] ([id], [issue_id], [user_id], [created_unix], [time]) VALUES (1, 1, 1, 946684800, 400)
INSERT [dbo].[tracked_time] ([id], [issue_id], [user_id], [created_unix], [time]) VALUES (2, 2, 2, 946684801, 3661)
INSERT [dbo].[tracked_time] ([id], [issue_id], [user_id], [created_unix], [time]) VALUES (3, 2, 2, 946684802, 1)
INSERT [dbo].[tracked_time] ([id], [issue_id], [user_id], [created_unix], [time]) VALUES (4, 4, -1, 946684802, 1)
INSERT [dbo].[tracked_time] ([id], [issue_id], [user_id], [created_unix], [time]) VALUES (5, 5, 2, 946684802, 1)
SET IDENTITY_INSERT [dbo].[tracked_time] OFF
SET IDENTITY_INSERT [dbo].[u2f_registration] ON 

INSERT [dbo].[u2f_registration] ([id], [name], [user_id], [raw], [counter], [created_unix], [updated_unix]) VALUES (1, N'U2F Key', 1, NULL, 0, 946684800, 946684800)
SET IDENTITY_INSERT [dbo].[u2f_registration] OFF
SET IDENTITY_INSERT [dbo].[user] ON 

INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (1, N'user1', N'user1', N'User One', N'user1@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', N'en-US', NULL, 1557052360, 1557052360, NULL, -1, 1, 1, NULL, NULL, 1, 0, N'avatar1', N'user1@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (2, N'user2', N'user2', N'User Two', N'user2@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar2', N'user2@example.com', NULL, 2, 1, 2, 6, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (3, N'user3', N'user3', N'User Three', N'user3@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 1, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, 0, NULL, NULL, 1, 0, N'avatar3', N'user3@example.com', NULL, NULL, 0, NULL, 3, NULL, 3, 2, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (4, N'user4', N'user4', N'User Four', N'user4@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar4', N'user4@example.com', NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (5, N'user5', N'user5', N'User Five', N'user5@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 0, 0, N'avatar5', N'user5@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (6, N'user6', N'user6', N'User Six', N'user6@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 1, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, 0, NULL, NULL, 1, 0, N'avatar6', N'user6@example.com', NULL, NULL, 0, NULL, 0, NULL, 1, 1, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (7, N'user7', N'user7', N'User Seven', N'user7@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 1, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, 0, NULL, NULL, 1, 0, N'avatar7', N'user7@example.com', NULL, NULL, 0, NULL, 0, NULL, 1, 1, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (8, N'user8', N'user8', N'User Eight', N'user8@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar8', N'user8@example.com', NULL, 1, 1, NULL, 0, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (9, N'user9', N'user9', N'User Nine', N'user9@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 0, 0, NULL, NULL, 1, 0, N'avatar9', N'user9@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (10, N'user10', N'user10', N'User Ten', N'user10@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar10', N'user10@example.com', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (11, N'user11', N'user11', N'User Eleven', N'user11@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar11', N'user11@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (12, N'user12', N'user12', N'User 12', N'user12@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar12', N'user12@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (13, N'user13', N'user13', N'User 13', N'user13@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar13', N'user13@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (14, N'user14', N'user14', N'User 14', N'user14@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar14', N'user13@example.com', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (15, N'user15', N'user15', N'User 15', N'user15@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar15', N'user15@example.com', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (16, N'user16', N'user16', N'User 16', N'user16@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar16', N'user16@example.com', NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (17, N'user17', N'user17', N'User 17', N'user17@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 1, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar17', N'user17@example.com', NULL, NULL, 0, NULL, 2, NULL, 3, 2, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (18, N'user18', N'user18', N'User 18', N'user18@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar18', N'user18@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (19, N'user19', N'user19', N'User 19', N'user19@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 1, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar19', N'user19@example.com', NULL, NULL, 0, NULL, 2, NULL, 1, 1, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (20, N'user20', N'user20', N'User 20', N'user20@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar20', N'user20@example.com', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, N'')
INSERT [dbo].[user] ([id], [lower_name], [name], [full_name], [email], [keep_email_private], [passwd], [must_change_password], [login_type], [login_source], [login_name], [type], [location], [website], [rands], [salt], [language], [created_unix], [updated_unix], [last_login_unix], [last_repo_visibility], [max_repo_creation], [is_active], [is_admin], [allow_git_hook], [allow_import_local], [allow_create_organization], [prohibit_login], [avatar], [avatar_email], [use_custom_avatar], [num_followers], [num_following], [num_stars], [num_repos], [description], [num_teams], [num_members], [diff_view_style]) VALUES (21, N'user21', N'user21', N'User 21', N'user21@example.com', NULL, N'7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', 0, NULL, 0, NULL, 0, NULL, NULL, NULL, N'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, 1, 0, NULL, NULL, 1, 0, N'avatar21', N'user21@example.com', NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, N'')
SET IDENTITY_INSERT [dbo].[user] OFF
SET IDENTITY_INSERT [dbo].[user_open_id] ON 

INSERT [dbo].[user_open_id] ([id], [uid], [uri], [show]) VALUES (1, 1, N'https://user1.domain1.tld/', 0)
INSERT [dbo].[user_open_id] ([id], [uid], [uri], [show]) VALUES (2, 1, N'http://user1.domain2.tld/', 1)
INSERT [dbo].[user_open_id] ([id], [uid], [uri], [show]) VALUES (3, 2, N'https://domain1.tld/user2/', 1)
SET IDENTITY_INSERT [dbo].[user_open_id] OFF
SET IDENTITY_INSERT [dbo].[version] ON 

INSERT [dbo].[version] ([id], [version]) VALUES (1, 77)
SET IDENTITY_INSERT [dbo].[version] OFF
SET IDENTITY_INSERT [dbo].[watch] ON 

INSERT [dbo].[watch] ([id], [user_id], [repo_id]) VALUES (1, 1, 1)
INSERT [dbo].[watch] ([id], [user_id], [repo_id]) VALUES (2, 4, 1)
INSERT [dbo].[watch] ([id], [user_id], [repo_id]) VALUES (3, 9, 1)
SET IDENTITY_INSERT [dbo].[watch] OFF
SET IDENTITY_INSERT [dbo].[webhook] ON 

INSERT [dbo].[webhook] ([id], [repo_id], [org_id], [url], [content_type], [secret], [events], [is_ssl], [is_active], [hook_task_type], [meta], [last_status], [created_unix], [updated_unix]) VALUES (1, 1, NULL, N'www.example.com/url1', 1, NULL, N'{"push_only":true,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":false}}', NULL, 1, NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[webhook] ([id], [repo_id], [org_id], [url], [content_type], [secret], [events], [is_ssl], [is_active], [hook_task_type], [meta], [last_status], [created_unix], [updated_unix]) VALUES (2, 1, NULL, N'www.example.com/url2', 1, NULL, N'{"push_only":false,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":true}}', NULL, 0, NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[webhook] ([id], [repo_id], [org_id], [url], [content_type], [secret], [events], [is_ssl], [is_active], [hook_task_type], [meta], [last_status], [created_unix], [updated_unix]) VALUES (3, 3, 3, N'www.example.com/url3', 1, NULL, N'{"push_only":false,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":true}}', NULL, 1, NULL, NULL, NULL, NULL, NULL)
SET IDENTITY_INSERT [dbo].[webhook] OFF
/****** Object:  Index [UQE_access_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_access_s] ON [dbo].[access]
(
	[user_id] ASC,
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_access_token_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_access_token_created_unix] ON [dbo].[access_token]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_access_token_uid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_access_token_uid] ON [dbo].[access_token]
(
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_access_token_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_access_token_updated_unix] ON [dbo].[access_token]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_access_token_sha1]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_access_token_sha1] ON [dbo].[access_token]
(
	[sha1] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_act_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_act_user_id] ON [dbo].[action]
(
	[act_user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_comment_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_comment_id] ON [dbo].[action]
(
	[comment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_created_unix] ON [dbo].[action]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_is_deleted]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_is_deleted] ON [dbo].[action]
(
	[is_deleted] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_is_private]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_is_private] ON [dbo].[action]
(
	[is_private] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_repo_id] ON [dbo].[action]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_action_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_action_user_id] ON [dbo].[action]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_attachment_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_attachment_issue_id] ON [dbo].[attachment]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_attachment_release_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_attachment_release_id] ON [dbo].[attachment]
(
	[release_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_attachment_uuid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_attachment_uuid] ON [dbo].[attachment]
(
	[uuid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_collaboration_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_collaboration_repo_id] ON [dbo].[collaboration]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_collaboration_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_collaboration_user_id] ON [dbo].[collaboration]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_collaboration_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_collaboration_s] ON [dbo].[collaboration]
(
	[repo_id] ASC,
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_comment_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_comment_created_unix] ON [dbo].[comment]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_comment_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_comment_issue_id] ON [dbo].[comment]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_comment_poster_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_comment_poster_id] ON [dbo].[comment]
(
	[poster_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_comment_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_comment_updated_unix] ON [dbo].[comment]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_commit_status_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_commit_status_created_unix] ON [dbo].[commit_status]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_commit_status_index]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_commit_status_index] ON [dbo].[commit_status]
(
	[index] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_commit_status_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_commit_status_repo_id] ON [dbo].[commit_status]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_commit_status_sha]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_commit_status_sha] ON [dbo].[commit_status]
(
	[sha] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_commit_status_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_commit_status_updated_unix] ON [dbo].[commit_status]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_commit_status_repo_sha_index]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_commit_status_repo_sha_index] ON [dbo].[commit_status]
(
	[index] ASC,
	[repo_id] ASC,
	[sha] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_deleted_branch_deleted_by_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_deleted_branch_deleted_by_id] ON [dbo].[deleted_branch]
(
	[deleted_by_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_deleted_branch_deleted_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_deleted_branch_deleted_unix] ON [dbo].[deleted_branch]
(
	[deleted_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_deleted_branch_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_deleted_branch_repo_id] ON [dbo].[deleted_branch]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_deleted_branch_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_deleted_branch_s] ON [dbo].[deleted_branch]
(
	[repo_id] ASC,
	[name] ASC,
	[commit] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_deploy_key_key_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_deploy_key_key_id] ON [dbo].[deploy_key]
(
	[key_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_deploy_key_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_deploy_key_repo_id] ON [dbo].[deploy_key]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_deploy_key_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_deploy_key_s] ON [dbo].[deploy_key]
(
	[key_id] ASC,
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_email_address_uid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_email_address_uid] ON [dbo].[email_address]
(
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_email_address_email]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_email_address_email] ON [dbo].[email_address]
(
	[email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_external_login_user_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_external_login_user_user_id] ON [dbo].[external_login_user]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_follow_follow]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_follow_follow] ON [dbo].[follow]
(
	[user_id] ASC,
	[follow_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_gpg_key_key_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_gpg_key_key_id] ON [dbo].[gpg_key]
(
	[key_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_gpg_key_owner_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_gpg_key_owner_id] ON [dbo].[gpg_key]
(
	[owner_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_hook_task_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_hook_task_repo_id] ON [dbo].[hook_task]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_closed_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_closed_unix] ON [dbo].[issue]
(
	[closed_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_created_unix] ON [dbo].[issue]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_deadline_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_deadline_unix] ON [dbo].[issue]
(
	[deadline_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_is_closed]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_is_closed] ON [dbo].[issue]
(
	[is_closed] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_is_pull]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_is_pull] ON [dbo].[issue]
(
	[is_pull] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_milestone_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_milestone_id] ON [dbo].[issue]
(
	[milestone_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_poster_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_poster_id] ON [dbo].[issue]
(
	[poster_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_repo_id] ON [dbo].[issue]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_updated_unix] ON [dbo].[issue]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_issue_repo_index]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_issue_repo_index] ON [dbo].[issue]
(
	[repo_id] ASC,
	[index] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_assignees_assignee_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_assignees_assignee_id] ON [dbo].[issue_assignees]
(
	[assignee_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_assignees_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_assignees_issue_id] ON [dbo].[issue_assignees]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_issue_dependency_issue_dependency]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_issue_dependency_issue_dependency] ON [dbo].[issue_dependency]
(
	[issue_id] ASC,
	[dependency_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_issue_label_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_issue_label_s] ON [dbo].[issue_label]
(
	[issue_id] ASC,
	[label_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_issue_user_uid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_issue_user_uid] ON [dbo].[issue_user]
(
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_issue_watch_watch]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_issue_watch_watch] ON [dbo].[issue_watch]
(
	[user_id] ASC,
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_label_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_label_repo_id] ON [dbo].[label]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_lfs_lock_owner_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_lfs_lock_owner_id] ON [dbo].[lfs_lock]
(
	[owner_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_lfs_lock_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_lfs_lock_repo_id] ON [dbo].[lfs_lock]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_lfs_meta_object_oid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_lfs_meta_object_oid] ON [dbo].[lfs_meta_object]
(
	[oid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_lfs_meta_object_repository_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_lfs_meta_object_repository_id] ON [dbo].[lfs_meta_object]
(
	[repository_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_lfs_meta_object_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_lfs_meta_object_s] ON [dbo].[lfs_meta_object]
(
	[oid] ASC,
	[repository_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_login_source_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_login_source_created_unix] ON [dbo].[login_source]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_login_source_is_actived]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_login_source_is_actived] ON [dbo].[login_source]
(
	[is_actived] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_login_source_is_sync_enabled]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_login_source_is_sync_enabled] ON [dbo].[login_source]
(
	[is_sync_enabled] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_login_source_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_login_source_updated_unix] ON [dbo].[login_source]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_login_source_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_login_source_name] ON [dbo].[login_source]
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_milestone_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_milestone_repo_id] ON [dbo].[milestone]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_mirror_next_update_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_mirror_next_update_unix] ON [dbo].[mirror]
(
	[next_update_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_mirror_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_mirror_repo_id] ON [dbo].[mirror]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_mirror_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_mirror_updated_unix] ON [dbo].[mirror]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notice_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notice_created_unix] ON [dbo].[notice]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_notification_commit_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_commit_id] ON [dbo].[notification]
(
	[commit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_created_unix] ON [dbo].[notification]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_issue_id] ON [dbo].[notification]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_repo_id] ON [dbo].[notification]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_source]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_source] ON [dbo].[notification]
(
	[source] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_status]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_status] ON [dbo].[notification]
(
	[status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_updated_by]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_updated_by] ON [dbo].[notification]
(
	[updated_by] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_updated_unix] ON [dbo].[notification]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_notification_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_notification_user_id] ON [dbo].[notification]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_oauth2_session_expires_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_oauth2_session_expires_unix] ON [dbo].[oauth2_session]
(
	[expires_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_org_user_is_public]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_org_user_is_public] ON [dbo].[org_user]
(
	[is_public] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_org_user_org_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_org_user_org_id] ON [dbo].[org_user]
(
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_org_user_uid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_org_user_uid] ON [dbo].[org_user]
(
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_org_user_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_org_user_s] ON [dbo].[org_user]
(
	[uid] ASC,
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_protected_branch_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_protected_branch_s] ON [dbo].[protected_branch]
(
	[repo_id] ASC,
	[branch_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_public_key_owner_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_public_key_owner_id] ON [dbo].[public_key]
(
	[owner_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_pull_request_base_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_pull_request_base_repo_id] ON [dbo].[pull_request]
(
	[base_repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_pull_request_has_merged]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_pull_request_has_merged] ON [dbo].[pull_request]
(
	[has_merged] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_pull_request_head_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_pull_request_head_repo_id] ON [dbo].[pull_request]
(
	[head_repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_pull_request_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_pull_request_issue_id] ON [dbo].[pull_request]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_pull_request_merged_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_pull_request_merged_unix] ON [dbo].[pull_request]
(
	[merged_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_pull_request_merger_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_pull_request_merger_id] ON [dbo].[pull_request]
(
	[merger_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_reaction_comment_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_reaction_comment_id] ON [dbo].[reaction]
(
	[comment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_reaction_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_reaction_created_unix] ON [dbo].[reaction]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_reaction_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_reaction_issue_id] ON [dbo].[reaction]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_reaction_type]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_reaction_type] ON [dbo].[reaction]
(
	[type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_reaction_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_reaction_user_id] ON [dbo].[reaction]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_reaction_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_reaction_s] ON [dbo].[reaction]
(
	[type] ASC,
	[issue_id] ASC,
	[comment_id] ASC,
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_release_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_release_created_unix] ON [dbo].[release]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_release_publisher_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_release_publisher_id] ON [dbo].[release]
(
	[publisher_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_release_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_release_repo_id] ON [dbo].[release]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_release_tag_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_release_tag_name] ON [dbo].[release]
(
	[tag_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_release_n]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_release_n] ON [dbo].[release]
(
	[repo_id] ASC,
	[tag_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repo_indexer_status_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repo_indexer_status_repo_id] ON [dbo].[repo_indexer_status]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_repo_redirect_lower_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repo_redirect_lower_name] ON [dbo].[repo_redirect]
(
	[lower_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_repo_redirect_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_repo_redirect_s] ON [dbo].[repo_redirect]
(
	[owner_id] ASC,
	[lower_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_repo_topic_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_repo_topic_s] ON [dbo].[repo_topic]
(
	[repo_id] ASC,
	[topic_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repo_unit_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repo_unit_created_unix] ON [dbo].[repo_unit]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repo_unit_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repo_unit_s] ON [dbo].[repo_unit]
(
	[repo_id] ASC,
	[type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_created_unix] ON [dbo].[repository]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_fork_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_fork_id] ON [dbo].[repository]
(
	[fork_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_is_bare]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_is_bare] ON [dbo].[repository]
(
	[is_bare] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_is_fork]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_is_fork] ON [dbo].[repository]
(
	[is_fork] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_is_mirror]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_is_mirror] ON [dbo].[repository]
(
	[is_mirror] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_is_private]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_is_private] ON [dbo].[repository]
(
	[is_private] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_repository_lower_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_lower_name] ON [dbo].[repository]
(
	[lower_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IDX_repository_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_name] ON [dbo].[repository]
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_repository_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_repository_updated_unix] ON [dbo].[repository]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_repository_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_repository_s] ON [dbo].[repository]
(
	[owner_id] ASC,
	[lower_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_review_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_review_created_unix] ON [dbo].[review]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_review_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_review_issue_id] ON [dbo].[review]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_review_reviewer_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_review_reviewer_id] ON [dbo].[review]
(
	[reviewer_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_review_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_review_updated_unix] ON [dbo].[review]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_star_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_star_s] ON [dbo].[star]
(
	[uid] ASC,
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_stopwatch_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_stopwatch_issue_id] ON [dbo].[stopwatch]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_stopwatch_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_stopwatch_user_id] ON [dbo].[stopwatch]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_team_org_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_team_org_id] ON [dbo].[team]
(
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_team_repo_org_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_team_repo_org_id] ON [dbo].[team_repo]
(
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_team_repo_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_team_repo_s] ON [dbo].[team_repo]
(
	[team_id] ASC,
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_team_unit_org_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_team_unit_org_id] ON [dbo].[team_unit]
(
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_team_unit_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_team_unit_s] ON [dbo].[team_unit]
(
	[team_id] ASC,
	[type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_team_user_org_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_team_user_org_id] ON [dbo].[team_user]
(
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_team_user_s]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_team_user_s] ON [dbo].[team_user]
(
	[team_id] ASC,
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_topic_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_topic_created_unix] ON [dbo].[topic]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_topic_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_topic_updated_unix] ON [dbo].[topic]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_topic_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_topic_name] ON [dbo].[topic]
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_tracked_time_issue_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_tracked_time_issue_id] ON [dbo].[tracked_time]
(
	[issue_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_tracked_time_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_tracked_time_user_id] ON [dbo].[tracked_time]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_two_factor_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_two_factor_created_unix] ON [dbo].[two_factor]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_two_factor_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_two_factor_updated_unix] ON [dbo].[two_factor]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_two_factor_uid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_two_factor_uid] ON [dbo].[two_factor]
(
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_u2f_registration_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_u2f_registration_created_unix] ON [dbo].[u2f_registration]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_u2f_registration_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_u2f_registration_updated_unix] ON [dbo].[u2f_registration]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_u2f_registration_user_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_u2f_registration_user_id] ON [dbo].[u2f_registration]
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_upload_uuid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_upload_uuid] ON [dbo].[upload]
(
	[uuid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_user_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_user_created_unix] ON [dbo].[user]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_user_is_active]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_user_is_active] ON [dbo].[user]
(
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_user_last_login_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_user_last_login_unix] ON [dbo].[user]
(
	[last_login_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_user_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_user_updated_unix] ON [dbo].[user]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_user_lower_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_user_lower_name] ON [dbo].[user]
(
	[lower_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_user_name]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_user_name] ON [dbo].[user]
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_user_open_id_uid]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_user_open_id_uid] ON [dbo].[user_open_id]
(
	[uid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQE_user_open_id_uri]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_user_open_id_uri] ON [dbo].[user_open_id]
(
	[uri] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQE_watch_watch]    Script Date: 05/05/2019 11:33:07 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQE_watch_watch] ON [dbo].[watch]
(
	[user_id] ASC,
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_webhook_created_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_webhook_created_unix] ON [dbo].[webhook]
(
	[created_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_webhook_is_active]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_webhook_is_active] ON [dbo].[webhook]
(
	[is_active] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_webhook_org_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_webhook_org_id] ON [dbo].[webhook]
(
	[org_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_webhook_repo_id]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_webhook_repo_id] ON [dbo].[webhook]
(
	[repo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IDX_webhook_updated_unix]    Script Date: 05/05/2019 11:33:07 ******/
CREATE NONCLUSTERED INDEX [IDX_webhook_updated_unix] ON [dbo].[webhook]
(
	[updated_unix] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[action] ADD  DEFAULT ((0)) FOR [is_deleted]
GO
ALTER TABLE [dbo].[action] ADD  DEFAULT ((0)) FOR [is_private]
GO
ALTER TABLE [dbo].[attachment] ADD  DEFAULT ((0)) FOR [download_count]
GO
ALTER TABLE [dbo].[attachment] ADD  DEFAULT ((0)) FOR [size]
GO
ALTER TABLE [dbo].[collaboration] ADD  DEFAULT ((2)) FOR [mode]
GO
ALTER TABLE [dbo].[deploy_key] ADD  DEFAULT ((1)) FOR [mode]
GO
ALTER TABLE [dbo].[login_source] ADD  DEFAULT ((0)) FOR [is_actived]
GO
ALTER TABLE [dbo].[login_source] ADD  DEFAULT ((0)) FOR [is_sync_enabled]
GO
ALTER TABLE [dbo].[mirror] ADD  DEFAULT ((1)) FOR [enable_prune]
GO
ALTER TABLE [dbo].[protected_branch] ADD  DEFAULT ((0)) FOR [can_push]
GO
ALTER TABLE [dbo].[protected_branch] ADD  DEFAULT ((0)) FOR [enable_merge_whitelist]
GO
ALTER TABLE [dbo].[protected_branch] ADD  DEFAULT ((0)) FOR [required_approvals]
GO
ALTER TABLE [dbo].[public_key] ADD  DEFAULT ((2)) FOR [mode]
GO
ALTER TABLE [dbo].[public_key] ADD  DEFAULT ((1)) FOR [type]
GO
ALTER TABLE [dbo].[public_key] ADD  DEFAULT ((0)) FOR [login_source_id]
GO
ALTER TABLE [dbo].[release] ADD  DEFAULT ((0)) FOR [is_draft]
GO
ALTER TABLE [dbo].[release] ADD  DEFAULT ((0)) FOR [is_prerelease]
GO
ALTER TABLE [dbo].[release] ADD  DEFAULT ((0)) FOR [is_tag]
GO
ALTER TABLE [dbo].[repository] ADD  DEFAULT ((0)) FOR [num_milestones]
GO
ALTER TABLE [dbo].[repository] ADD  DEFAULT ((0)) FOR [num_closed_milestones]
GO
ALTER TABLE [dbo].[repository] ADD  DEFAULT ((0)) FOR [is_fork]
GO
ALTER TABLE [dbo].[repository] ADD  DEFAULT ((0)) FOR [size]
GO
ALTER TABLE [dbo].[repository] ADD  DEFAULT ((1)) FOR [is_fsck_enabled]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ((0)) FOR [must_change_password]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ((0)) FOR [login_source]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ((-1)) FOR [max_repo_creation]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ((1)) FOR [allow_create_organization]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ((0)) FOR [prohibit_login]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ((0)) FOR [num_following]
GO
ALTER TABLE [dbo].[user] ADD  DEFAULT ('') FOR [diff_view_style]
GO
ALTER TABLE [dbo].[user_open_id] ADD  DEFAULT ((0)) FOR [show]
GO
USE [master]
GO
ALTER DATABASE [gitea] SET  READ_WRITE 
GO
